import "/js/config.js";
import "/js/auth-bridge.js";
import "/js/api.js";
import "/js/forms.js";
import "/js/roles.js";
import "/js/include.js";
