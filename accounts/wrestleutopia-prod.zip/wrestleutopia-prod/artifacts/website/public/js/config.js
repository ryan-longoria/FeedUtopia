window.WU_API = "https://go2gft4394.execute-api.us-east-2.amazonaws.com";
window.WU_MEDIA_BASE = "https://d178p8k1vmj1zs.cloudfront.net";
