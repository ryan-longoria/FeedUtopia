from __future__ import annotations

import hashlib
import logging
import os
import re
from typing import Any, Dict, Optional
import html

import cloudscraper
import feedparser

logger = logging.getLogger()
logger.setLevel(logging.INFO)

DEFAULT_FEED_URL = "https://www.animenewsnetwork.com/newsroom/rss.xml"
ALLOWED_CATEGORIES = {"anime", "people", "just for fun", "live-action"}

_scraper = cloudscraper.create_scraper(
    browser={
        "custom": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/124.0.0.0 Safari/537.36 FeedFetcher-Lambda"
        )
    }
)

_ILLEGAL_XML_RE = re.compile(r"[\x00-\x08\x0B\x0C\x0E-\x1F\x7F-\x9F]")
_AMP_RE = re.compile(r"&(?!(?:amp|lt|gt|apos|quot|#\d+|#x[\da-fA-F]+);)")


def _clean_xml(text: str) -> str:
    """Remove control chars and escape stray ampersands."""
    text = _ILLEGAL_XML_RE.sub("", text)
    return _AMP_RE.sub("&amp;", text)


def _download_and_parse(url: str) -> feedparser.FeedParserDict:
    """
    Download `url`, scrub illegal bytes, and parse with feedparser.

    Raises:
        cloudscraper.exceptions.CloudflareChallengeError or
        requests.exceptions.RequestException on network issues.
    """
    resp = _scraper.get(url, timeout=10)
    resp.raise_for_status()

    cleaned = _clean_xml(resp.text)
    return feedparser.parse(cleaned)


def fetch_latest_news_post(feed_url: str = DEFAULT_FEED_URL) -> Optional[Dict[str, str]]:
    """
    Return the first feed entry whose <category> matches ALLOWED_CATEGORIES.

    Args:
        feed_url: RSS feed URL to query.

    Returns:
        Dict with 'title', 'link', 'description' or None if nothing matches.
    """
    try:
        feed = _download_and_parse(feed_url)
    except Exception as exc:
        logger.error("Could not download RSS feed: %s", exc)
        return None

    if feed.bozo and not feed.entries:
        logger.error("Unreadable RSS feed after scrubbing: %s", feed.bozo_exception)
        return None

    for entry in feed.entries:
        for tag in entry.get("tags", []):
            if tag.get("term", "").strip().lower() in ALLOWED_CATEGORIES:
                return {
                    "title": entry.get("title", ""),
                    "link": entry.get("link", ""),
                    "description": entry.get("description", ""),
                }

    logger.info("No matching posts found in RSS feed.")
    return None


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Step-Functions task handler.

    Returns:
        {
            "status": "post_found" | "no_post",
            "post_id": <md5(link)> ,    # only when post_found
            "post":    {...}            # only when post_found
        }
    """
    feed_url = os.getenv("ANIME_FEED_URL", DEFAULT_FEED_URL)

    post = fetch_latest_news_post(feed_url)
    if post:
        link = post["link"] or ""
        stable_post_id = hashlib.md5(link.encode("utf-8")).hexdigest()
        logger.info("Found post; stable_post_id=%s", stable_post_id)

        return {"status": "post_found", "post_id": stable_post_id, "post": post}

    logger.info("No post found")
    return {"status": "no_post"}